```json
{"operation":"sync","dryRun":false,"configurationRevision":"62e9688017a8c8fda70164b1196ffb5265543cff","configurationOrigin":"wangyingang/sing-box-config-manager@acceptance-automation-c904077f-08bb-4ced-b77f-d06e64e23acf","target":{"repository":"wangyingang/sing-box-rule-artifacts","branch":"acceptance-automation-c904077f-08bb-4ced-b77f-d06e64e23acf"},"status":"failed","exitCode":1,"results":[],"error":"gh failed: GET repos/wangyingang/sing-box-rule-artifacts: gh: Bad credentials (HTTP 401)"}
```

Overall result: failed; completed changes remain in effect
