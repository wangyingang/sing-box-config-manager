import collections,json,pathlib,re,subprocess,sys
root=pathlib.Path.cwd(); out=root/'.verification/issue-96'; phase=sys.argv[1]
base='7075bfc3f6a900c67a07e32e53e5a8aabc4ed1b4'
folder='packages/rule-set-pipeline/test/integration'
files=subprocess.check_output(['git','ls-tree','-r','--name-only',base,folder],text=True).splitlines() if phase=='before' else [str(p) for p in root.glob(folder+'/*.test.ts')]
patterns=[]
for file in files:
 if not file.endswith('.test.ts'): continue
 text=subprocess.check_output(['git','show',f'{base}:{file}'],text=True) if phase=='before' else pathlib.Path(file).read_text()
 for m in re.finditer(r"\btest\(([\"'`])([^\n]+?)\1\s*,",text):
  template=m[2]
  pieces=re.split(r'\$\{[^}]+\}',template)
  patterns.append((re.compile('^'+'.*?'.join(re.escape(x) for x in pieces)+'$'),file,sum(map(len,pieces))))
counts=collections.defaultdict(lambda:{'matchedTopLevelTests':0,'bodyMilliseconds':0}); unmatched=[]
for line in (out/phase/'integration.log').read_text().splitlines():
 m=re.search(r'^packages/rule-set-pipeline test:integration: [✔✖] (.*?) \(([0-9.]+)ms\)$',line)
 if not m: continue
 matches=[(score,f) for p,f,score in patterns if p.match(m[1])]
 if matches:
  file=max(matches)[1];counts[file]['matchedTopLevelTests']+=1;counts[file]['bodyMilliseconds']+=float(m[2])
 else:unmatched.append(m[1])
result={'note':'Sum of matched top-level test body durations from Node spec reporter. Excludes module startup, nested subtests (their duration is included by parent) and unmatched names; not CI or file process wall time. Files run concurrently, so sums are not additive across files.','suites':dict(counts),'unmatched':unmatched}
(out/f'{phase}-suite-times.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({pathlib.Path(k).name:v for k,v in counts.items()},ensure_ascii=False))
print('unmatched',unmatched)
