## Spec

审查固定点：`0daf266cd293ecd65d11447c0aada642d6d3c734...HEAD`，覆盖提交 `bd8599d`、`75b5e60`、`7ae0651`、`a55d99b`。来源：#96 正文、#93 Testing Decisions、当前代码和旧远端验收。只读审查，未运行远端写入。

- **[P2] 固定官方样本的独立输出／来源断言尚未完整迁入。** #96 要求“迁入旧 publication、configured-publication、activation、rollback、rebuild、configured-rebuild 中独有的 HTTPS 回读或来源断言”，且“替代覆盖通过后才删除对应旧测试”。旧 `test/acceptance/configured-rebuild.test.ts:80` 对官方 OpenAI/Anthropic 的 `artifact.termCount` 分别固定为 25/19；旧 `configured-publication.test.ts:67` 固定 `build.definition.list`。新 `test/acceptance/rules-operations.test.ts:210-218` 虽检查固定 `report.inputCount`，却只将 `artifact.termCount` 与同次构建的 `report.outputTermCount` 比较，并未检查 `build.definition.list`。转换同时漏规则并更新 Report/Manifest 时，或构建记录错误指向别的列表时，新探针仍可通过，不能作为这两项独有断言的等价退役证据。请为首轮固定样本明确核验原有输出数量和各集预期列表；重新验证替代覆盖后再退役对应旧验收。

未发现其他已确认的需求遗漏、越界行为或实现逻辑问题。四集共享输入、CIDR 独立变化、同语义零写入、共同／单列表失败、constructor 和订阅字段重排均有当前服务覆盖；底层真实原生校验和写入保护未被本 diff 修改。旧远端文件和旧命令的删除属于已知待执行步骤，不计为 finding；真实 GitHub 第三轮的运行结果不在本次静态审查结论内。

## 修复复核（794838b）

首次 finding 保留如上，处理结果：**静态复核已解决**。`rules-operations.test.ts` 的 `inspectCandidate` 现独立校验 `build.definition.list`，首轮三域名集将固定 25/19/49 同时用于输入数和各产物 `termCount`，旧单集固定样本明确校验 `category-ai-!cn` 和 214。这样 Report 与 Manifest 的共同少规则错误不能再仅靠彼此一致通过。

同时核对增强的版本选择断言：pin 返回值必须为请求的原 `versionId`；resume 的文件和来源必须恢复到 pin 前最新交付，且版本不同于原版本；历史证据和稳定 HTTPS 回读仍保留。逐阶段 checkpoint 只增加证据保存，不替换真实原生验证或应用服务写入守卫。此次增量未发现新增 Spec 问题，当前未解决 finding 为 0。

复核范围为 `794838b` 的实际测试增量及相关旧断言；未重跑测试、未执行远端写入。第三轮按主 Agent 提供的信息为主动中止，不能计为通过；第四轮实际验收仍待结果，旧文件及命令须在替代覆盖真实通过后再退役。

## 分批 HTTPS 回读复核（d1e2903）

静态复核 `794838b..d1e2903` 的远端测试调整，未发现新增 Spec 问题，当前未解决 finding 仍为 0。

换列表、pin、resume 的每个中间提交仍经 `check` 按不可变 commit URL 校验实际文件摘要与字节；兄弟集的当前记录、稳定文件和 `activation.json` 仍与操作前不可变快照逐项比较。逐集 pin 仍要求选中原版本并恢复原文件；逐集 resume 仍要求恢复 pin 前最新来源和文件。所有 pin 完成后，对四集 canonical URL 回读原字节；所有 resume 完成后，对四集相同 canonical URL 回读最新字节，预期字节来自前述不可变 HTTPS 快照，不靠状态记录自证。历史候选七文件与原始来源断言继续逐集执行。因此只推迟 canonical URL 的观察时间，没有丢失旧 activation/rollback 的稳定 URL 收敛、历史字节恢复和兄弟集不变断言；旧两项探针本身也将 canonical 回读集中在逐集切换完成之后。

四集固定输入、CIDR-only、Release 更新、固定样本 termCount/list、无变化零写入及删除断言仍保留；全 pinned sync 的零上游请求断言也保留。混合 pinned 与独立成功的服务覆盖在本地当前测试中继续存在。一次 TypeError 后重试下载仍读取真实 HTTPS，不缓存或替换回读字节，也不重放底层写入。延长整体 timeout 不改变验收判定。

此次仅复核代码，未重跑测试或执行远端写入。第五轮主动中止、第六轮网络失败均不能计为整轮通过；实际清理、生产前后状态和后续完整远端验收结果以主 Agent 保存的运行证据为准。静态等价结论不能替代整轮通过证据，旧文件／命令仍须等替代覆盖通过后退役。

## 最终退役增量复核（f543071）

最终审查范围为 `0daf266cd293ecd65d11447c0aada642d6d3c734...f54307109855242f7813d584c1e59ed5127d4e3a`；此次聚焦 `c74376d` 的删除与 `f543071` 的说明，复用此前已完成的代码复核。**未发现新增 Spec 问题；首轮 P2 已解决，当前未解决 finding 为 0。**

已独立读取第七轮 JSON 和日志：受测 `1527f51e9df077eff61682114e270ca31e1ab42b`、工作区干净；1 项通过，失败／跳过／取消／todo 均为 0；588 条 HTTPS 回读，`remaining=[]`、`cleanupErrors=[]`、生产 `before` 与 `after` 相同。归档 probe SHA-256 为 `fb6b2b80a27d8a4d329afed07f798c2db61b316e47ca800d45bdb55113e936b2`，与最终测试文件字节一致；操作记录包括四集新增、CIDR-only、Release 更新、三域名换列表、逐集 pin/resume、两轮 canonical、历史候选、旧固定样本、无变化与全部删除。因此旧远端验收的删除已有先行完整替代通过证据。

删除的六个旧远端文件与四个旧命令符合 #96 的退役范围，没有同名兼容别名。`official-rulesets-lifecycle` 仅移除已迁移的交付断言；清理代次、保留／丢弃集合、pin、清理后稳定 HTTPS、旧版本拒绝选择及清理后恢复断言仍保留，构造样本的旧业务步骤继续存在，并明确标注其仅为 #98 的准备。当前说明与映射准确区分本票完成范围、T5 留存和 #101 的入口收敛，不将本轮通过扩展为清理、自动化或父工单完成。

本轮只读复核未重新执行测试、未执行远端写入。统一 verify 正在运行，其最终统计、CI 和云端审查结果不在本报告结论中；须由主 Agent 按实际结果补入交付记录。
