import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { configuredEnvironment, upstream } from '../../packages/rule-set-pipeline/test/integration/configured-activation-fixture.js';
import { checkRules } from '../../packages/rule-set-pipeline/src/check-rules.js';
import { activateRules } from '../../packages/rule-set-pipeline/src/activation.js';
const binary = process.env.SING_BOX_TEST_BINARY!;
const digest = (bytes: Buffer) => createHash('sha256').update(bytes).digest('hex');
const out = 'packages/rule-set-pipeline/test/fixtures/historical';
await mkdir(out, { recursive: true });
for (const name of ['shared', 'split', 'srs-only', 'incomplete']) {
 const directory = await mkdtemp(join(tmpdir(), 'capture-history-'));
 try {
  const target = name === 'split' ? 'main' : 'acceptance-issue-99-history';
  const env = await configuredEnvironment(binary, directory, target);
  const commit = env.repository.commit;
  env.repository.commit = async (expected, files, message) => {
   if (name === 'incomplete' && Object.keys(files).some(path => path.endsWith('/manifest.json'))) throw new Error('fixture capture: interrupted before metadata');
   return commit(expected, files, message);
  };
  const publish = name === 'incomplete' ? async () => { throw new Error('fixture capture: interrupted before metadata'); } : env.publish;
  const candidates = name === 'srs-only' ? await env.candidates() : undefined;
  const result = candidates ? { exitCode: 0 } : await checkRules({ binary, configuration: env.configuration, stateDirectory: directory,
   ...(name === 'incomplete' ? { selectedIds: ['openai'] } : {}), fetch: upstream(1).fetcher,
   publication: { repository: env.repository, commit: publish, download: env.transport.download },
   activation: env.transport, subscriptions: Object.fromEntries(env.ids.map(id => [id, env.subscription(id)])) });
  assert.equal(result.exitCode, name === 'incomplete' ? 1 : 0, JSON.stringify(result));
  if (name !== 'incomplete') {
   const stable = await env.repository.snapshot(target);
   const record = candidates ? { candidateEvidenceUrl: candidates.openai.evidenceUrl } : JSON.parse((await stable.read('stable/openai/activation.json'))!.toString());
   const subscription = env.subscription('openai');
   if (name === 'srs-only') {
    // The old writer explicitly supported caller-provided SRS-only subscriptions.
    delete (subscription.projections.route.formats as any).source;
    delete (subscription.projections['dns-query'].formats as any).source;
   }
   await activateRules({ ...env.options('openai', record.candidateEvidenceUrl), subscription });
  }
  const blobs: Record<string, string> = {};
  const add = (bytes: Buffer) => { const sha = digest(bytes); blobs[sha] = bytes.toString('base64'); return sha; };
  const trees: Record<string, Record<string, string>> = {};
  const heads: Record<string, string> = {};
  for (const branch of new Set([env.repository.branch, target])) {
   const snapshot = await env.repository.snapshot(branch); heads[branch] = snapshot.head;
   trees[snapshot.head] = Object.fromEntries(await Promise.all(snapshot.paths.map(async path => [path, add((await snapshot.read(path))!)])));
  }
  for (const [head, tree] of env.snapshots) trees[head] ??= Object.fromEntries(Object.entries(tree).filter(([path]) => !path.startsWith('pipeline/')).map(([path, bytes]) => [path, add(bytes)]));
  const downloads = Object.fromEntries([...env.stored].map(([url, bytes]) => [url, add(bytes)]));
  const capture = { schemaVersion: 1, provenance: { sourceCommit: '1f9ad68d5bf99915e0ce57834023f3b6b7796e98',
   recipe: name === 'srs-only' ? 'configuredEnvironment.candidates() (configured updateRules) then activateRules(openai, SRS-only)' : name === 'incomplete' ? 'checkRules(upstream(1), selectedIds=[openai]); repository commit interrupted before manifest.json' : 'checkRules(upstream(1)) then activateRules(openai)' ,
   fixture: 'test/integration/configured-activation-fixture.ts', binaryVersion: '1.14.4', binarySha256: digest(await readFile(binary)),
   network: 'in-memory external Git/Release transport; no production data', variant: name },
   configuration: env.configuration, target, branch: env.repository.branch, heads, trees, downloads, blobs };
  await writeFile(`${out}/${name}.json`, JSON.stringify(capture, null, 2) + '\n');
  console.log(name, Object.keys(blobs).length, Object.keys(trees).length);
 } finally { await rm(directory, { recursive: true, force: true }); }
}
