import collections,json,pathlib,re,subprocess,sys
root=pathlib.Path.cwd(); out=root/'.verification/issue-99'; phase=sys.argv[1]
identity=json.loads((out/phase/'summary.json').read_text())['source']['commit']
folder='packages/rule-set-pipeline/test/integration'
files=subprocess.check_output(['git','ls-tree','-r','--name-only',identity,folder],text=True).splitlines()
patterns=[]
for file in files:
 if not file.endswith('.test.ts'): continue
 source=subprocess.check_output(['git','show',f'{identity}:{file}'],text=True)
 for match in re.finditer(r"\btest\(([\"'`])([^\n]+?)\1\s*,",source):
  pieces=re.split(r'\$\{[^}]+\}',match[2]); patterns.append((re.compile('^'+'.*?'.join(re.escape(x) for x in pieces)+'$'),file,sum(map(len,pieces))))
counts=collections.defaultdict(lambda:{'matchedTopLevelTests':0,'bodyMilliseconds':0}); unmatched=[]
for line in (out/phase/'integration.log').read_text().splitlines():
 match=re.search(r'^packages/rule-set-pipeline test:integration: [✔✖] (.*?) \(([0-9.]+)ms\)$',line)
 if not match: continue
 matches=[(score,file) for pattern,file,score in patterns if pattern.match(match[1])]
 if matches:
  file=max(matches)[1]; counts[file]['matchedTopLevelTests']+=1; counts[file]['bodyMilliseconds']+=float(match[2])
 else: unmatched.append(match[1])
result={'sourceCommit':identity,'note':'Matched top-level body duration sums; excludes startup; concurrent suites are not additive. Unmatched names retained explicitly. Patterns read from measured source commit.','suites':dict(counts),'unmatched':unmatched}
(out/f'{phase}-suite-times.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({pathlib.Path(k).name:v for k,v in counts.items()},ensure_ascii=False))
print('unmatched',len(unmatched))
