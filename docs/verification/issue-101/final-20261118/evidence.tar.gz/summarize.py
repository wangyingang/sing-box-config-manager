import collections,datetime,json,pathlib,re,sys
root=pathlib.Path(__file__).resolve().parent
phase=sys.argv[1]
summary=json.loads((root/phase/'summary.json').read_text())
records=[json.loads(line) for line in (root/f'{phase}-processes.jsonl').read_text().splitlines()]
start=datetime.datetime.fromisoformat(summary['startedAt'].replace('Z','+00:00'))
finish=datetime.datetime.fromisoformat(summary['finishedAt'].replace('Z','+00:00'))
records=[r for r in records if start <= datetime.datetime.fromisoformat(r['startedAt'].replace('Z','+00:00')) <= finish]
counts=collections.defaultdict(collections.Counter)
for r in records:
    name=pathlib.Path(r['file']).name
    if name not in ('sing-box','sing-box-issue-22','sing-box-wrapper','version','compile','decompile','match','semantic','drift-0','drift-1','drift-2'):continue
    if not r.get('pid'):continue
    args=r['args']
    purpose=' '.join(args[:2]) if args and args[0]=='rule-set' else args[0] if args else 'unknown'
    category='directOrCopy' if name in ('sing-box','sing-box-issue-22') else 'faultWrapper'
    counts[category][purpose]+=1
steps=[]
for s in summary['steps']:
    a=datetime.datetime.fromisoformat(s['startedAt'].replace('Z','+00:00'))
    b=datetime.datetime.fromisoformat(s['finishedAt'].replace('Z','+00:00'))
    steps.append({'name':s['name'],'seconds':(b-a).total_seconds(),'suites':s['suites']})
result={'source':summary['source'],'status':summary['status'],'scope':summary['scope'],'wallSeconds':(finish-start).total_seconds(),
    'steps':steps,'nativeInvocations':dict(counts),'nativeTotals':{k:sum(v.values()) for k,v in counts.items()},
    'tools':summary['tools'],'note':'Direct child-process invocations of real sing-box paths/copies; forwarding and fault wrappers shown separately. Includes verification preflight; failed commands within negative tests remain counted. No shell grandchildren counted twice. Same observer and scope before/after; no remote acceptance.'}
(root/f'{phase}-metrics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['tools']},indent=2))
