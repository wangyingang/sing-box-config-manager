受测提交 6766f1801969483db88f1e9857aded0688cba836，范围 check-native。
从该提交的隔离工作区根目录解压到 .verification/issue-101-final/。
基线原始完整归档见 docs/verification/issue-94/before.tar.gz；此归档仅重复保留比较需要的摘要和观察器。
复算：python3 .verification/issue-101-final/summarize.py final；python3 .verification/issue-101-final/suite-times.py final。
校验：node scripts/inspect-evidence.mjs --evidence .verification/issue-101-final/final --out <新的输出目录>。
GitHub 日志为本次实际运行的下载副本，远端写入验收未执行。
