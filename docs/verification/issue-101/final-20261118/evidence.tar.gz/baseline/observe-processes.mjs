import cp from 'node:child_process';
import { appendFileSync } from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
import { promisify } from 'node:util';
const output = process.env.RULE_TEST_PROCESS_LOG;
if (output) {
  for (const method of ['spawn', 'execFile']) {
    const original = cp[method];
    cp[method] = function(file, args, ...rest) {
      const started = performance.now();
      const child = Reflect.apply(original, this, [file, args, ...rest]);
      // Observe only process identity and public command category. Do not change the
      // executable, argv, callbacks, bytes, exit status or native tool identity.
      const record = { parent: process.pid, pid: child.pid, method, file: String(file),
        args: Array.isArray(args) ? args.filter(a => typeof a === 'string').map(a => a.includes('.test.') ? a : a).slice(0, 4) : [],
        startedAt: new Date().toISOString() };
      child.once('close', (code, signal) => {
        appendFileSync(output, JSON.stringify({ ...record, code, signal, durationMs: performance.now() - started }) + '\n');
      });
      return child;
    };
    // Keep execFile promisify semantics while routing it through the observer.
    if (method === 'execFile') cp[method][promisify.custom] = (file, args, options) => new Promise((resolve, reject) => {
      cp[method](file, args, options, (error, stdout, stderr) => {
        if (error) { error.stdout = stdout; error.stderr = stderr; reject(error); }
        else resolve({ stdout, stderr });
      });
    });
  }
  syncBuiltinESMExports();
}
