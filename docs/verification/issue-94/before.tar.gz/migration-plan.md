# #94 迁移前映射（7075bfc）

本映射先于测试编辑保存；最终测试名和通过证据写入仓库交付记录。#94 只处理 M1、M4 查询及 M5 pin 竞争。

| 旧文件及变体 | 当前契约与落点 | 退役／保留条件 |
| --- | --- | --- |
| configured-activation：逐集切换 | 当前 pin 选择保留版本，目标及兄弟集稳定字节逐项比对 | 新 pin 覆盖通过后删除 |
| configured-activation：wrong-set、duplicate-ids、missing、extra、evidence、srs | 候选证据验证边界集中错误矩阵；当前 status 与 pin 拒绝 | 新边界及拒绝交付覆盖通过后删除 |
| configured-activation：native | pin 使用真实 sing-box；缺 binary 失败 | 新 pin 原生覆盖通过后删除 |
| configured-activation：usage、capability、reuse、path、v1 | 当前订阅与稳定路径契约；不能接受损坏或不兼容交付 | 新 status/pin 契约矩阵通过后删除 |
| configured-activation：old-record、old-bytes | 损坏当前记录／字节停止写入 | 当前规则操作及新 pin 断言通过后删除 |
| configured-activation：applied、not-applied、unknown、superseded、readback、registration | 当前 pin 通过 writeId、交付回执和远端 head 核实；status 只读 | 新 pin 故障矩阵通过后删除 |
| configured-activation：receipt | 本地回执不再参与当前五操作 | 按 ADR 0001 退役 |
| configured-activation：rejected | 远端未应用时保留当前，登记未决操作后按当前契约恢复 | 新 pin not-applied 覆盖通过后删除 |
| configured-activation：双分支 maintenance、generation、head；不同集竞争 | 当前配置、维护、代次、head 与 CAS 保护 | 新 pin 竞争覆盖通过后删除 |
| configured-activation：同候选新决定、再次指定必须换修订 | 重复 pin 同版本幂等；新版本决定取代旧操作 | 幂等覆盖通过后退役旧修订要求 |
| configured-activation：订阅字段顺序 | 顺序不改变既有订阅语义 | 迁到当前 pin 后删除整文件 |
| configured-rollback：逐集历史选择；换列表后选择旧来源 | pin 可选任何仍保留、合格的版本，包括旧来源 | 复用 rules-operations 换源失败／旧来源重选；新双格式版本选择补字节和兄弟集断言 |
| configured-rollback：other-set、wrong-identity、missing-candidate、candidate-bytes、subscription、native、stale-head | 当前规则身份、证据、订阅、原生和并发保护 | 替代覆盖通过后删除 |
| configured-rollback：history-json、history-bytes、historical-candidate | 不再用历史激活 commit／本地索引选择；以候选及 versionId 为准 | 退役旧回滚索引，保留候选证据拒绝 |
| china-ip-delivery：前三组非客户端测试（4 项） | CIDR pin、契约、证据、响应丢失 | 双格式当前 pin 覆盖通过后删除这些段落 |
| china-ip-delivery：同一真实客户端 | #97 负责 M7 | 保留测试及必要准备 |
| china-ip-delivery：未交付候选不可回滚（末项） | 合格且保留、尚未交付的候选可 pin | 新未交付候选可选择覆盖通过后退役 |
| remote-faults：retained、domains.srs、build.json、readback.json、changed-current-bytes | 缺失或替换的保留证据不可选，pin 不交付 | 新边界与 status/pin 覆盖通过后删除该组 |
| remote-faults：三阶段响应丢失、缓存、代次／维护／head、缺状态组 | #95 的恢复范围，非本票删除对象 | 原段落保留，避免提前退役 |
| remote-status：SRS-only 首项 | #99 一次性历史转换 | 保留样本及历史读取 |
| remote-status：8 种订阅／文件记录错误 | 当前 status 候选不可选；pin 拒绝不兼容订阅；损坏稳定字节失败 | 新覆盖通过后删除该组 |
| remote-status：空状态、待核实当前、有效历史版本、缺／坏证据与残缺阶段 | 当前 status 的 current/candidates/pendingOperation，零写入且不恢复 | 新 status 覆盖通过后删除对应段落 |
| remote-status：历史订阅缺失／不兼容、旧对象仍存在、非法历史索引 | 版本选择看保留候选，不看旧 rollbackTargets／historyComplete | 候选覆盖通过后退役旧字段要求 |
| remote-status：未归属稳定文件、维护预览 | #98 清理范围 | 保留测试和必要准备 |
