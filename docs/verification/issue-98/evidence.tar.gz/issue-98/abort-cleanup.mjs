import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { ghJson, ARTIFACT_REPOSITORY } from '../../packages/rule-set-pipeline/src/publication.ts';
import { gitMaintenanceRefs, branchRef } from '../../packages/rule-set-pipeline/src/maintenance-refs.ts';
const path = new URL('./remote-3.json', import.meta.url);
const evidence = JSON.parse(await readFile(path, 'utf8'));
assert.equal(evidence.aborted, true);
assert.match(evidence.target, /^acceptance-issue-98-[a-f0-9-]{36}$/);
const api = endpoint => ghJson(['api', endpoint]);
const production = async () => ({
  main: (await api(`repos/${ARTIFACT_REPOSITORY}/git/ref/heads/main`)).object.sha,
  candidates: (await api(`repos/${ARTIFACT_REPOSITORY}/git/ref/heads/candidates`)).object.sha,
  variables: await api('repos/wangyingang/sing-box-config-manager/actions/variables'),
});
const beforeAbortCleanup = await production();
const encoded = await api(`repos/${ARTIFACT_REPOSITORY}/contents/pipeline/state.json?ref=${evidence.target}`);
const journal = JSON.parse(Buffer.from(encoded.content, 'base64').toString());
assert.equal(journal.targetBranch, evidence.target);
const runIds = [journal.cleanupRun?.id, journal.cleanupCheckpoint?.id].filter(Boolean);
assert.ok(runIds.every(id => /^[a-f0-9-]{36}$/.test(id)));
const allowed = ref => ref === branchRef(evidence.target) || runIds.some(id =>
  new RegExp(`^refs/heads/maintenance-${id}-(files|metadata|evidence|journal|old-journal)$`).test(ref));
const refs = gitMaintenanceRefs();
const removed = (await refs.list()).filter(({ref}) => allowed(ref));
await refs.update(removed.map(({ref,head}) => ({ref,before:head})));
const remaining = (await refs.list()).filter(({ref}) => allowed(ref));
const afterAbortCleanup = await production();
Object.assign(evidence, { runIds, beforeAbortCleanup, afterAbortCleanup,
  removedRefs: removed, remaining, cleanupErrors: [], endedAt: new Date().toISOString(),
  limitation: 'Original run before/after production snapshot was not finalized because this diagnostic run was terminated; the explicit abort cleanup has its own before/after comparison.' });
await writeFile(path, JSON.stringify(evidence,null,2)+'\n');
assert.deepEqual(remaining,[]);assert.deepEqual(afterAbortCleanup,beforeAbortCleanup);
console.log(JSON.stringify({target:evidence.target,removed:removed.map(x=>x.ref),remaining,abortCleanupProductionUnchanged:true}));
