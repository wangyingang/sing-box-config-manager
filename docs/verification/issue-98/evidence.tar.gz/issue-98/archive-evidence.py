from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path.cwd(); evidence=root/'.verification/issue-98'; output=root/'docs/verification/issue-98'
summary=json.loads((evidence/'complete/summary.json').read_text())
remote=json.loads((evidence/'remote-4.json').read_text())
assert summary['status']=='passed' and remote.get('passed') is True
assert remote['remaining']==[] and remote['cleanupErrors']==[] and remote['before']==remote['after']
assert all(json.loads((evidence/f'remote-{i}.json').read_text()).get('remaining')==[] for i in [1,2,3])
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
(evidence/'source.diff').write_bytes(subprocess.check_output(['git','diff','--binary','1f9ad68',source]))
(evidence/'commits.txt').write_bytes(subprocess.check_output(['git','log','--oneline','1f9ad68..'+source]))
output.mkdir(exist_ok=True)
archive=output/'evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar: tar.add(evidence,arcname='issue-98')
metrics=json.loads((evidence/'complete-metrics.json').read_text())
manifest={'archive':archive.name,'byteLength':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'archiveSourceAtCreation':source,'fixedPoint':'1f9ad68','local':{'source':summary['source'],'scope':summary['scope'],'status':summary['status'],'steps':metrics['steps']},
 'remoteCleanup':{'sourceIdentity':remote['sourceIdentity'],'target':remote['target'],'passed':remote['passed'],'runIds':remote['runIds'],'readbacks':len(remote['readbacks']),'switchCount':remote['switchCount'],'remaining':remote['remaining'],'productionUnchanged':True},
 'remoteTransport':{'log':'issue-98/transport-remote.log','passedTests':1},
 'limitations':['Remote rounds 1 and 2 failed and were cleaned; round 3 was deliberately aborted and explicitly cleaned. Round 3 has only an abort-cleanup before/after production comparison, not a finalized original-run comparison.', 'Local full validation predates the acceptance-only assertion/type fixes and retirement; targeted typecheck and the real isolated probe cover those changes. CI and cloud-review coverage is recorded separately in the PR delivery record.']}
(output/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'archive':str(archive),'byteLength':manifest['byteLength'],'sha256':manifest['sha256']},ensure_ascii=False))
