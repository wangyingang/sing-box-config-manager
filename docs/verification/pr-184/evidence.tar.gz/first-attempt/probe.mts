import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { configuredRuleInput, parseBuildConfiguration } from '<task-worktree>/packages/rule-set-pipeline/src/configuration.ts';
import { decompileRuleBinary } from '<task-worktree>/packages/rule-set-pipeline/src/native.ts';
import { syncRules } from '<task-worktree>/packages/rule-set-pipeline/src/rules-operations.ts';
import { getRulesStatus } from '<task-worktree>/packages/rule-set-pipeline/src/rules-status.ts';
import { githubRulesRepository } from '<task-worktree>/packages/rule-set-pipeline/src/rules-repository.ts';
import { createGitCommit } from '<task-worktree>/packages/rule-set-pipeline/src/publication-repository.ts';
import { ARTIFACT_REPOSITORY, ghJson, GitHubHttpError } from '<task-worktree>/packages/rule-set-pipeline/src/publication.ts';
import { sha256 } from '<task-worktree>/packages/rule-set-pipeline/src/release.ts';
import { retryProbeRead } from '<task-worktree>/packages/rule-set-pipeline/test/acceptance/formal-v4-sources.ts';
import { fixtureConfigurationYaml } from '<task-worktree>/packages/rule-set-pipeline/test/fixtures/formal-configuration.ts';

const target = 'acceptance-china-domains-' + randomUUID().slice(0, 12);
const output = '<first-attempt-evidence>';
const binary = '<user-home>/.local/bin/sing-box';
const configPath = 'packages/rule-set-pipeline/config/rulesets.yml';
const run = (file: string, args: string[]) => execFileSync(file, args, { encoding: 'utf8', cwd: '<task-worktree>', timeout: 30000 });
const git = (...args: string[]) => run('git', args).trim();
const baseRevision = git('rev-parse', 'origin/main');
const revision = git('rev-parse', 'HEAD');
assert.equal(git('status', '--porcelain'), '');
const preparation = (sha: string) => {
  const parsed = parseBuildConfiguration(git('show', sha + ':' + configPath));
  const rule = parsed.ruleSets.find(rule => rule.id === 'china-domains');
  assert.ok(rule && 'artifact' in rule);
  const source = configuredRuleInput(parsed, rule);
  assert.ok(source.version === 'url' || source.version === 'git-branch');
  return {
    revision: sha,
    origin: 'acceptance probe from checkout',
    content: fixtureConfigurationYaml({
      schemaVersion: 4, candidateRetentionDays: parsed.candidateRetentionDays,
      sources: { [rule.source]: source }, target: { repository: ARTIFACT_REPOSITORY, branch: target }, ruleSets: [rule],
    }),
  };
};
const baseline = preparation(baseRevision);
const updated = preparation(revision);
const evidence: Record<string, any> = {
  target, baseRevision, revision, worktreeClean: true, binary: { version: run(binary, ['version']).trim(), sha256: sha256(await readFile(binary)) },
  baselineConfigurationSha256: sha256(baseline.content), updatedConfigurationSha256: sha256(updated.content),
  startedAt: new Date().toISOString(), operations: {},
};
const archive = () => writeFile(join(output, 'isolated-sync.json'), JSON.stringify(evidence, null, 2) + '\n');
const token = run('gh', ['auth', 'token']).trim();
assert.ok(token);
const repoPath = 'repos/' + ARTIFACT_REPOSITORY + '/';
const request: typeof ghJson = async (args, input) => {
  const endpoint = args[1];
  const method = args.includes('--method') ? args[args.indexOf('--method') + 1] : 'GET';
  assert.ok(endpoint === repoPath.slice(0, -1) || endpoint.startsWith(repoPath));
  if (method !== 'GET') {
    if (endpoint === repoPath + 'git/refs') {
      assert.equal(method, 'POST');
      assert.equal((input as { ref: string }).ref, 'refs/heads/' + target);
    } else if (endpoint === repoPath + 'git/refs/heads/' + target) {
      assert.equal(method, 'PATCH');
      assert.equal((input as { force: boolean }).force, false);
    } else {
      assert.equal(method, 'POST');
      assert.match(endpoint.slice(repoPath.length), /^git\/(blobs|trees|commits)$/);
    }
  }
  const transport = method === 'GET' ? retryProbeRead : fetch;
  const response = await transport('https://api.github.com/' + endpoint, {
    method, headers: { Authorization: 'Bearer ' + token, Accept: 'application/vnd.github+json', 'Content-Type': 'application/json' },
    body: input === undefined ? undefined : JSON.stringify(input), signal: AbortSignal.timeout(120000),
  });
  if (!response.ok) throw new GitHubHttpError(response.status, method + ' ' + endpoint + ' HTTP ' + response.status);
  return response.status === 204 ? null : response.json();
};
const api = (path: string, input?: unknown) => request(['api', repoPath + path, ...(input === undefined ? [] : ['--method', 'POST', '--input', '-'])], input);
const production = async () => {
  const [main, candidates, data] = await Promise.all([
    api('git/ref/heads/main'), api('git/ref/heads/candidates'),
    ghJson(['api', 'repos/wangyingang/sing-box-config-manager/actions/variables']),
  ]);
  return { main: main.object.sha, candidates: candidates.object.sha,
    variables: data.variables.filter((entry: { name: string }) => ['RULE_UPDATE_ENABLED', 'RULE_CLEANUP_ENABLED'].includes(entry.name)) };
};
const readRaw = async (address: string, expected: string) => {
  for (let attempt = 1; attempt <= 16; attempt++) {
    const response = await retryProbeRead(address, { cache: 'no-store', signal: AbortSignal.timeout(60000) });
    if (response.ok) {
      const bytes = Buffer.from(await response.arrayBuffer());
      if (sha256(bytes) === expected) return bytes;
    } else await response.body?.cancel();
    if (attempt < 16) await sleep(5000);
  }
  throw new Error('Stable Raw did not return the expected bytes: ' + address);
};
let observed = baseline;
let failNewSource = false;
const repository = githubRulesRepository(target, request);
const stage = () => ({
  context: {
    targetBranch: target, repository, binary, token, allowWrites: true,
    readConfiguration: async () => observed,
    fetch: async (url: string | URL | Request, init?: RequestInit) => {
      if (failNewSource && String(url).endsWith('/geosite-geolocation-cn.srs')) return new Response(null, { status: 503 });
      return retryProbeRead(url, init);
    },
  },
  onProgress: ({ stage, logicalId }: { stage: string; logicalId?: string }) => console.log(stage, logicalId ?? ''),
});
const matches = (file: string, format: string, domain: string) =>
  run(binary, ['rule-set', 'match', file, domain, '--format', format, '--disable-color']).includes('match rules.');

try {
  evidence.productionBefore = await production();
  assert.deepEqual(await api('git/matching-refs/heads/' + target), []);
  evidence.seed = await createGitCommit(api, { 'README.md': Buffer.from('Isolated china-domains acceptance\n') }, '初始化 china-domains 隔离验收');
  await api('git/refs', { ref: 'refs/heads/' + target, sha: evidence.seed });
  console.log('target', target);
  await archive();

  const first = await syncRules(stage());
  evidence.operations.baseline = first;
  await archive();
  assert.equal(first.status, 'success', JSON.stringify(first.results.map(row => row.error)));
  const baselineDelivery = first.results[0].current!;
  assert.equal('kind' in baselineDelivery.source && baselineDelivery.source.kind, 'fixed-url');

  observed = updated;
  failNewSource = true;
  const failed = await syncRules(stage());
  evidence.operations.failedSource = failed;
  await archive();
  assert.equal(failed.status, 'failed');
  assert.match(failed.results[0].error!, /HTTP 503/);
  assert.deepEqual(failed.results[0].current, baselineDelivery);
  const stablePrefix = 'https://raw.githubusercontent.com/' + ARTIFACT_REPOSITORY + '/' + target + '/';
  const stablePaths = ['stable/china-domains/domains.json', 'stable/china-domains/domains.srs'];
  const oldFiles = await Promise.all(stablePaths.map(path => readRaw(stablePrefix + path, baselineDelivery.files[path].sha256)));
  evidence.failureRetained = stablePaths.map((path, index) => ({ url: stablePrefix + path, sha256: sha256(oldFiles[index]) }));
  await archive();

  failNewSource = false;
  const next = await syncRules(stage());
  evidence.operations.switched = next;
  await archive();
  assert.equal(next.status, 'success', JSON.stringify(next.results.map(row => row.error)));
  const active = next.results[0].current!;
  assert.ok('commit' in active.source);
  assert.equal(active.source.repository, 'SagerNet/sing-geosite');
  assert.equal(active.source.file.path, 'geosite-geolocation-cn.srs');
  assert.notEqual(active.candidateId, baselineDelivery.candidateId);
  assert.deepEqual(active.subscription, baselineDelivery.subscription);

  const status = await getRulesStatus({ ...stage(), id: 'china-domains' });
  evidence.operations.status = status;
  assert.equal(status.status, 'success');
  assert.equal(status.rules?.[0].configurationDifference, 'none');
  assert.deepEqual(status.rules?.[0].current, active);
  assert.deepEqual(status.rules?.[0].stableUrls.slice().sort(), stablePaths.map(path => stablePrefix + path).sort());

  const snapshot = await repository.snapshot();
  evidence.finalHead = snapshot.head;
  const snap = await snapshot.read('candidates/' + active.candidateId + '/input.source.srs');
  assert.ok(snap);
  assert.equal(sha256(snap), active.source.inputSha256);
  assert.equal(snap.length, active.source.inputBytes);
  const rawUpstream = await readRaw(active.source.file.url, active.source.inputSha256);
  assert.deepEqual(rawUpstream, snap);
  const files = await Promise.all(stablePaths.map(path => readRaw(stablePrefix + path, active.files[path].sha256)));
  await Promise.all(files.map((bytes, index) => writeFile(join(output, stablePaths[index].split('/').at(-1)!), bytes)));
  await writeFile(join(output, 'input.source.srs'), snap);
  const decoded = JSON.parse(await decompileRuleBinary(snap, binary));
  const delivered = JSON.parse(files[0].toString());
  assert.deepEqual(delivered, { version: 4, rules: decoded.rules });
  assert.deepEqual(JSON.parse(await decompileRuleBinary(files[1], binary)).rules, decoded.rules);
  evidence.readback = files.map((bytes, index) => ({ url: stablePrefix + stablePaths[index], sha256: sha256(bytes), bytes: bytes.length }));
  evidence.matches = [];
  for (const [domain, expected] of [['a1.mzstatic.com', true], ['baidu.com', true], ['arbitrary-label.alibaba', true], ['alibaba', false],
    ['arbitrary-label.cn', false], ['google.com', false]] as const) {
    const values = [
      matches(join(output, 'input.source.srs'), 'binary', domain),
      matches(join(output, 'domains.json'), 'source', domain),
      matches(join(output, 'domains.srs'), 'binary', domain),
    ];
    assert.deepEqual(values, [expected, expected, expected], domain);
    evidence.matches.push({ domain, expected, upstreamSrs: values[0], stableJson: values[1], stableSrs: values[2] });
  }
  evidence.result = 'passed';
} catch (error) {
  evidence.result = 'failed';
  evidence.error = error instanceof Error ? error.stack : String(error);
  throw error;
} finally {
  evidence.productionAfter = await production();
  evidence.productionUnchanged = JSON.stringify(evidence.productionBefore) === JSON.stringify(evidence.productionAfter);
  evidence.endedAt = new Date().toISOString();
  await archive();
  assert.deepEqual(evidence.productionAfter, evidence.productionBefore);
  console.log(evidence.result, target, evidence.finalHead ?? '', join(output, 'isolated-sync.json'));
}
