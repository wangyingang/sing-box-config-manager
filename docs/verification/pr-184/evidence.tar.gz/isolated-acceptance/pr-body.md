## Summary

`china-domains` 将通过现有的两个稳定订阅地址交付 SagerNet 的 `geosite-geolocation-cn.srs`。此前该集直接读取 V2Fly DLC 的同名列表。

```text
SagerNet/sing-geosite:rule-set/geosite-geolocation-cn.srs
  → 按 Git commit 读取并在候选中保存原始 SRS
  → 用 sing-box 1.14.4 解码并保留完整规则结构
  → 沿用 v4 JSON 构建、SRS 编译、加载与双格式回读
  → stable/china-domains/domains.{json,srs}
```

`sing-box-srs` 支持 Source Format v4 可表达的域名、IP 和其他原生条件及逻辑规则。解码或重建失败时保留上一份正式交付。候选恢复使用留存的原始输入。

## Evidence

- 本地原生回归已通过。DLC 基线交付后，损坏的 SRS 保留原订阅。模拟候选写入中断和旧上游 commit 消失后，`sync` 通过输入快照恢复候选，并从原地址交付新版 JSON 和 SRS。测试输入包含域名规则，以及含 IPv4、IPv6、端口和反转条件的逻辑规则。
- 真实 GitHub 隔离分支 `acceptance-china-domains-c8b49f87-380` 依次执行 DLC 基线、给 SRS 下载注入 HTTP 503、恢复下载后三次 `sync`。失败时从两个原地址取到 DLC 字节。恢复后 `status` 显示当前交付来自 SagerNet 的 `e15c5cbcfa72`。
- 原地址的首次轮询超时。独立 HTTPS 复验在同一分支地址读到两个新版，摘要与固定交付 commit 一致。[JSON](https://raw.githubusercontent.com/wangyingang/sing-box-rule-artifacts/acceptance-china-domains-c8b49f87-380/stable/china-domains/domains.json) · [SRS](https://raw.githubusercontent.com/wangyingang/sing-box-rule-artifacts/acceptance-china-domains-c8b49f87-380/stable/china-domains/domains.srs) · [固定交付 commit](https://github.com/wangyingang/sing-box-rule-artifacts/tree/86016a077b0f6031c8c00242b83758b580c02a56/stable/china-domains)
- 两种产物的规则结构与原始官方 SRS 一致，6 个原生匹配探针结果一致。DLC 版的 `a1.mzstatic.com` 未匹配，换源后匹配。产物仓库生产 `main`、`candidates` 和生产门禁前后相同。
- `pnpm check`、本地原生换源和恢复回归、GitHub Workspace checks 均通过。PR CI 按工作流设置跳过全量 Native sing-box 作业。云端 Codex 审查覆盖 `9a34398`，无 findings。

## Merge Danger

**Door: 双向。** 恢复原 DLC 输入绑定后执行 `sync`，可从原订阅地址重新交付 DLC 版本。

**Blast Radius: china-domains。** 下次获授权的生产同步会采用新的匹配集合，实质换源按现有规则撤销旧 pin。此 PR 期间的运行目标为专用 `acceptance-*` 分支，生产切换另行授权。
