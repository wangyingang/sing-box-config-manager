from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import tempfile
import time

evidence = Path(__file__).parent
document = evidence / 'isolated-sync.json'
binary = '<user-home>/.local/bin/sing-box'

def stamp():
    return datetime.now(timezone.utc).isoformat()

def digest(content):
    return hashlib.sha256(content).hexdigest()

def native(*args):
    run = subprocess.run([binary, 'rule-set', *map(str, args), '--disable-color'], capture_output=True, check=True)
    return run.stdout + run.stderr

def fetch(address, expected, first_deadline):
    results = []
    while time.monotonic() < first_deadline:
        try:
            with tempfile.TemporaryDirectory(prefix='isolated-raw-') as temp:
                headers = Path(temp) / 'headers'
                attempt = subprocess.run(['curl', '-fsSL', '--max-time', '20', '-D', str(headers), address], capture_output=True, check=True)
                sha = digest(attempt.stdout)
                response_headers = dict(line.strip().split(': ', 1) for line in headers.read_text().splitlines() if ': ' in line.strip())
                results.append({'timestamp': stamp(), 'sha256': sha, 'cacheControl': response_headers.get('cache-control'),
                                'cacheStatus': response_headers.get('x-cache')})
                if sha == expected:
                    return attempt.stdout, results
        except subprocess.CalledProcessError as error:
            results.append({'timestamp': stamp(), 'error': error.stderr.decode(errors='replace').strip()})
        time.sleep(12)
    raise RuntimeError(f'Expected {expected} at {address}. Last response: {results[-1] if results else "-"}')

deadline = time.monotonic() + 720
while time.monotonic() < deadline:
    try:
        state = json.loads(document.read_text())
        if state.get('finalHead') and state.get('operations', {}).get('status', {}).get('status') == 'success':
            break
        if state.get('result') == 'failed' and not state.get('finalHead'):
            raise RuntimeError(state['error'])
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    time.sleep(10)
else:
    raise RuntimeError('Stable sync status was not recorded within 12 minutes')

old = state['operations']['baseline']['results'][0]['current']
current = state['operations']['switched']['results'][0]['current']
assert old['subscription'] == current['subscription']
assert state['operations']['failedSource']['results'][0]['current'] == old
assert state['operations']['status']['rules'][0]['current'] == current
source = current['source']
prefix = 'https://raw.githubusercontent.com/wangyingang/sing-box-rule-artifacts/'
fixed = prefix + state['finalHead'] + '/'
checks = [(fmt, f, current['subscription']['formats'][fmt]['url'], current['files'][f]['sha256'])
          for fmt, f in [('source', 'stable/china-domains/domains.json'), ('binary', 'stable/china-domains/domains.srs')]]

result = {'revision': state['revision'], 'target': state['target'], 'head': state['finalHead'],
          'upstreamCommit': source['commit'], 'version': current['versionId'], 'start': stamp(), 'checks': [], 'matches': []}
with ThreadPoolExecutor(max_workers=4) as pool:
    raw = [(spec, pool.submit(fetch, spec[2], spec[3], time.monotonic() + 390),
            pool.submit(fetch, fixed + spec[1], spec[3], time.monotonic() + 60)) for spec in checks]
    original, _ = fetch(fixed + 'candidates/' + current['candidateId'] + '/input.source.srs', source['inputSha256'], time.monotonic() + 90)
    (evidence / 'verified-input.source.srs').write_bytes(original)
    for (fmt, path, url, expected), stable, immutable in raw:
        stable_bytes, attempts = stable.result()
        fixed_bytes, _ = immutable.result()
        assert stable_bytes == fixed_bytes
        (evidence / ('verified-' + Path(path).name)).write_bytes(stable_bytes)
        result['checks'].append({'format': fmt, 'url': url, 'fixedUrl': fixed + path, 'sha256': expected,
                                 'bytes': len(stable_bytes), 'attempts': attempts})
    # Confirm the sample's observed match change against the prior DLC delivery.
    original_stable = state['operations']['baseline']['observedHeads']['stable']
    old_url = prefix + original_stable + '/stable/china-domains/domains.json'
    baseline, _ = fetch(old_url, old['files']['stable/china-domains/domains.json']['sha256'], time.monotonic() + 60)
    (evidence / 'verified-baseline.json').write_bytes(baseline)

raw_input = evidence / 'verified-input.source.srs'
raw_output = evidence / 'verified-domains.srs'
json_output = evidence / 'verified-domains.json'
with tempfile.TemporaryDirectory(prefix='isolated-rule-match-') as temp:
    directory = Path(temp)
    decoded_input = directory / 'in.json'
    decoded_output = directory / 'out.json'
    native('decompile', raw_input, '-o', decoded_input)
    native('decompile', raw_output, '-o', decoded_output)
    input_rules = json.loads(decoded_input.read_text())['rules']
    assert json.loads(json_output.read_text()) == {'version': 4, 'rules': input_rules}
    assert json.loads(decoded_output.read_text())['rules'] == input_rules
    assert b'match rules.' not in native('match', evidence / 'verified-baseline.json', 'a1.mzstatic.com', '--format', 'source')
    for domain, expected in [('a1.mzstatic.com', True), ('baidu.com', True), ('arbitrary-label.alibaba', True),
                             ('alibaba', False), ('arbitrary-label.cn', False), ('google.com', False)]:
        targets = [(raw_input, 'binary'), (raw_output, 'binary'), (json_output, 'source')]
        for target, fmt in targets:
            assert (b'match rules.' in native('match', target, domain, '--format', fmt)) == expected, (domain, target)
        result['matches'].append({'domain': domain, 'matchesInAll': expected})
result['result'] = 'passed'
result['end'] = stamp()
(evidence / 'stable-readback.json').write_text(json.dumps(result, indent=2) + '\n')
print(result['result'], result['head'], evidence / 'stable-readback.json')
