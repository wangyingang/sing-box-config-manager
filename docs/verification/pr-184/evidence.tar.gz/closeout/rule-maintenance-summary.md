```json
{"operation":"sync","dryRun":false,"configurationRevision":"b586688a042f209bd6b54160504a0ede89531464","configurationOrigin":"wangyingang/sing-box-config-manager@main","target":{"repository":"wangyingang/sing-box-rule-artifacts","branch":"main"},"status":"disabled","exitCode":0,"results":[],"error":"RULE_UPDATE_ENABLED is disabled; configuration has not been applied (未应用)"}
```

Overall result: success (see each operation for disabled/unchanged)
