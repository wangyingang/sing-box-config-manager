## Summary

v4 规则集可共用一个 GitHub 仓库和分支，通过各自的 `data.file` 与 `data.format` 交付 Clash、CIDR 或域名后缀文件。同步为同一分支固定一个 commit，再按各文件分别交付 JSON 和 SRS。

Clash 清单支持按上游类型 include/exclude。选中但跳过的条目按类型计数。全部选中项均被跳过时，已有的两种订阅保留上一版，首次构建等待下次成功。同批次的独立文件继续处理。空文件或正常筛选为空会生成可加载的空规则集。

Closes #172

## Evidence

- 专用场景为 `test/integration/rules-github-branch.test.ts`，目标为 `acceptance-issue-172`。上游 HTTP 与产物 Git 由隔离 fixture 提供。使用 sing-box 1.14.4 验证两种格式的真实加载、域名与 IP 命中、源 CIDR 及端口条件。
- 实现前，新场景在 GitHub 分支配置入口失败。实现后已验证分支复用、类型筛选、ASN 计数、失败隔离和空产物。补充验证覆盖非法配置在上游访问前被拒绝。
- 在 #176 合入后更新至 `main` 的 `01cff57`。干净工作区的 `853d496` 通过 `check-native`，446 项常规测试与 349 项原生集成测试全部通过。专用场景含 16 项测试，证据路径为 `.verification/issue-172-853d496/`，已核验文件摘要。
- 常规 CI 的变更检测和工作区检查通过。PR 触发规则跳过 Linux 原生 job，本次原生覆盖来自本地 macOS。 [CI](https://github.com/wangyingang/sing-box-config-manager/actions/runs/45160348581)
- 本地规范审查补齐配置文档，收敛转换查找，并恢复 v3 的非空输入校验。规格审查补齐下划线关键词、源 CIDR 和源／目标端口。云端 Codex 审查覆盖 `853d496`，未发现问题。 [云端审查](https://github.com/wangyingang/sing-box-config-manager/pull/180#issuecomment-7098650161)

## Merge Danger

可通过回退源码变更恢复原有配置能力。影响 v4 隔离规则集的 GitHub 分支输入，以及空单产物的构建与候选复验。正式 16 集配置由 #174 迁移。若其他并行 PR 先合入，合并前基于最新 `main` 复验受影响的行为。
