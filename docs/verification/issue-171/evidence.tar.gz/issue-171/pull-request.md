Closes #171

## Summary

v4 同步现在支持从固定 HTTPS URL 获取 DLC 和 ChatGPT Voice。DLC 多集共享下载与可选 SHA-256 校验，再按各自的命名列表与标签过滤条件生成 JSON/SRS。Voice 整文件转换为 IPv4/IPv6 规则。

```text
DLC 正文和可选摘要 → 各规则集选列表、筛标签 → 去标签 → JSON + SRS
ChatGPT Voice 正文 → 提取 CIDR → JSON + SRS
```

摘要错误影响同源规则集，缺失列表只影响选中该列表的规则集。受影响规则集保留旧交付。存在空列表或过滤结果为空时，发布可原生加载的空产物。规范化匹配内容相同时，保留现有版本并记录本次成功输入。

## Evidence

- 变更前，带 `sha256Url` 的 v4 DLC 配置在解析时被拒绝。新增集成测试经 sing-box 1.14.4 验证两种交付格式、四种标签组合、空集、故障隔离及版本保留。
- 使用 V2Fly 官方 DLC 发布 `20261123085441` 的正文与摘要，以及 OpenAI 官方 Voice JSON，向本票的 `acceptance-issue-171` 内存目标交付三套规则。两种格式共验证 12 个匹配结果。[V2Fly Release](https://github.com/v2fly/domain-list-community/releases/tag/20261123085441) · [OpenAI Voice JSON](https://openai.com/chatgpt-voice.json)
- 基于合入 #169 的 `main` 提交 `01cff57` 复验。干净的 `710bb9c` 通过 446 项常规检查和 337 项原生集成测试，失败和跳过均为 0。证据摘要及完整性报告位于任务 worktree 的 `.verification/issue-171/`。
- 同一提交通过 GitHub Detect changes 和 Workspace checks。PR 触发的 CI 按工作流设置跳过 Native sing-box。云端 Codex 审查完成，无 findings 或待解决讨论。[CI](https://github.com/wangyingang/sing-box-config-manager/actions/runs/45159566646) · [云端审查](https://github.com/wangyingang/sing-box-config-manager/pull/177#issuecomment-7098548567)

## Merge Danger

**Door** · 可回退的代码变更。正式 16 集配置的迁移由 #174 跟踪。

**Blast Radius** · Rule Set Pipeline 的 v4 固定 URL 获取及候选验证。DLC 文本导出直接拼接正则和属性。符合标签语法且未转义的小写尾部沿用现有属性解析约定。[V2Fly 导出程序](https://github.com/v2fly/domain-list-community/blob/master/cmd/datdump/main.go)
