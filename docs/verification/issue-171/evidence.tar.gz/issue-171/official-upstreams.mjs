import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { stringify } from 'yaml';
import { syncRules } from './src/rules-operations.ts';
import { rulesEnvironment } from './test/fixtures/rules-environment.ts';

const binary = process.env.SING_BOX_TEST_BINARY;
const branch = 'acceptance-issue-171';
const env = rulesEnvironment(binary, branch);
const url = 'https://github.com/v2fly/domain-list-community/releases/latest/download/dlc.dat_plain.yml';
const requests = [];
const config = stringify({
  schemaVersion: 4, candidateRetentionDays: 30,
  target: { repository: 'wangyingang/sing-box-rule-artifacts', branch },
  sources: {
    dlc: { fetch: { method: 'url', url, sha256Url: url + '.sha256sum' }, format: 'v2fly-dlc-yaml' },
    voice: { fetch: { method: 'url', url: 'https://openai.com/chatgpt-voice.json' }, format: 'openai-voice-json' },
  },
  ruleSets: Object.fromEntries(['openai', 'anthropic', 'voice'].map(id => [id, {
    data: id === 'voice' ? { source: 'voice' } : { source: 'dlc', list: id },
    publishPath: `stable/${id}`,
    artifact: id === 'voice' ? 'ips' : 'domains',
  }])),
});
env.context.readConfiguration = async () => ({ origin: 'official-upstreams-isolated-target', revision: '171', content: config });
env.context.fetch = async (address, init) => {
  assert.equal(new Headers(init?.headers).has('Authorization'), false);
  const response = await fetch(address, init);
  requests.push({ host: new URL(address).host, status: response.status });
  return response;
};
const result = await syncRules({ context: env.context });
assert.equal(result.status, 'success', JSON.stringify(result.results.map(({ id, status, error }) => ({ id, status, error }))));
const snapshot = await env.context.repository.snapshot();
const directory = mkdtempSync(join(tmpdir(), 'rules-171-official-'));
try {
  const observations = [];
  for (const { id, status, current } of result.results) {
    assert.equal(status, 'delivered');
    const path = `stable/${id}/${id === 'voice' ? 'ips' : 'domains'}`;
    const json = JSON.parse((await snapshot.read(path + '.json')).toString());
    assert.doesNotMatch(JSON.stringify(json), /:@(?:cn|!cn)/);
    const samples = {
      openai: { 'api.openai.com': true, 'claude.ai': false },
      anthropic: { 'claude.ai': true, 'api.openai.com': false },
      voice: id === 'voice' ? { [json.rules[0].ip_cidr[0].split('/')[0]]: true, '192.0.2.1': false } : {},
    }[id];
    const matches = [];
    for (const [extension, format] of [['json', 'source'], ['srs', 'binary']]) {
      const local = join(directory, `rules.${extension}`);
      writeFileSync(local, await snapshot.read(`${path}.${extension}`));
      for (const [sample, expected] of Object.entries(samples)) {
        const match = spawnSync(binary, ['rule-set', 'match', local, sample, '--format', format], { encoding: 'utf8' });
        assert.equal(match.status, 0, match.stderr);
        const actual = (match.stdout + match.stderr).includes('match rules.');
        assert.equal(actual, expected, `${id} ${format} ${sample}`);
        matches.push({ format, sample, matched: actual });
      }
    }
    observations.push({ id, status, source: current.source, files: current.files, matches });
  }
  console.log(JSON.stringify({ target: branch, targetTransport: 'in-memory', requests, observations }, null, 2));
} finally {
  rmSync(directory, { recursive: true, force: true });
}
