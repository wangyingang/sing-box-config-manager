## Summary

以往 Rule Subscription v2 位于 Pipeline 契约目录，链接容易让读者误以为正式交付时需要生成 DNS 和 Route 用途。现在从消费入口即可找到 v2 说明、Schema 和示例，从 Pipeline 契约首页可以直接找到生产记录格式。

```text
Pipeline 候选 → Manifest v3：固定 JSON/SRS、字节数、SHA-256
Pipeline 交付 → 外层记录 v2 → subscription v3：稳定 JSON/SRS 地址
可信宿主 → Rule Subscription v2：稳定地址、用途与能力 → Compiler / Recipe v2
可信宿主 → Artifact Manifest v2：固定修订与用途映射 → Compiler / Recipe v1
```

- 将现行 Rule Subscription v2 迁至 `packages/config-compiler/contracts/`。已废止的 v1 文档、Schema、示例归档至 `docs/history/rule-subscription-v1/`，历史交接链接固定到原提交。
- 为固定输入 Artifact Manifest v2 单列说明。它与 Manifest v3 的 Schema 继续共址，v3 通过相对引用复用单个文件的字段定义。
- 更新模块导读、领域索引和 ADR。Pipeline 源码中的历史校验器通过原有开发依赖加载 v2 JSON，构建时收录相同字节，正式运行所需依赖保持原样。

## Evidence

- 使用 sing-box 1.14.4 执行 `pnpm check`，470 项测试全部通过，类型检查、构建、打包后 Schema 解析及 workspace smoke 均通过。另行执行 Compiler 订阅编译、发布和快照交付的 20 项定向测试，全部通过。
- 在仓库外仅提供 Pipeline 声明的三个运行时依赖，确认无法解析 Compiler 时仍可加载 Pipeline 公共入口、读取正式 v4 配置并校验 v2 样本。
- 迁移的四个 Schema／示例 JSON 与原提交逐字节一致。v1、v2 单集示例分别通过本版校验并被另一版拒绝，三集 v2 示例通过校验。已核对修改文档中的 165 个本地链接（含标题锚点）及 4 个固定提交链接。
- 使用 `git merge-tree` 检查本提交和 #182 当前提交可以无冲突合并。本 PR 单独面向 main。
- 最新提交 `db69c57` 的 [CI 工作区检查](https://github.com/wangyingang/sing-box-config-manager/actions/runs/45197322559) 已通过。完整 Native sing-box 作业按 PR 条件跳过。[云端复审](https://github.com/wangyingang/sing-box-config-manager/pull/183#issuecomment-7104495080) 覆盖同一提交，未报告问题，行内讨论为零。

## Merge Danger

**Door:** 可通过回退提交恢复原路径。

**Blast Radius:** 源码仓库内的文档、Schema 文件路径和构建打包。外部工具若硬编码了旧的 v2 Schema 路径，需改指向 Compiler 目录。规则订阅 URL、编译输入格式和生产交付记录格式沿用现值。
