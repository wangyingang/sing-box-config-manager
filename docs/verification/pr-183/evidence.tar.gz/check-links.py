from pathlib import Path
import collections, json, re, subprocess, unicodedata
from urllib.parse import unquote, urlsplit
def git(*args):
    return subprocess.check_output(['git', *args], text=True).splitlines()
files=set(git('diff','--name-only','--diff-filter=ACMRT','origin/main...HEAD')+git('ls-files','--others','--exclude-standard'))
root=Path.cwd()
prefix='/wangyingang/sing-box-config-manager/blob/'
def anchors(path):
    out=set()
    seen=collections.Counter()
    for h in re.findall(r'^#{1,6}\s+(.+)$',path.read_text(),re.M):
        h=re.sub(r'\[([^]]+)\]\([^)]+\)',r'\1',h).strip().lower()
        slug=''.join(c for c in h if c in '_- ' or not unicodedata.category(c).startswith(('P','S'))).replace(' ','-')
        out.add(slug if not seen[slug] else f'{slug}-{seen[slug]}')
        seen[slug]+=1
    return out
local=pinned=0
errors=[]
for f in sorted(files):
    p=Path(f)
    if p.suffix!='.md' or not p.is_file(): continue
    for label,dest in re.findall(r'\[([^\[\]\n]*)\]\(([^)\s]+)\)',p.read_text()):
        u=urlsplit(dest)
        if u.netloc=='github.com' and u.path.startswith(prefix):
            rev, sep, path=unquote(u.path.removeprefix(prefix)).partition('/')
            if sep and rev=='main':
                if not Path(path).exists(): errors.append((f,dest,'missing on proposed main'))
            elif re.fullmatch('[a-f0-9]{7,40}',rev):
                if subprocess.run(['git','cat-file','-e',f'{rev}:{path}'],capture_output=True).returncode: errors.append((f,dest,'prior commit'))
                pinned+=1
            continue
        if u.scheme or u.netloc: continue
        path=p.parent/unquote(u.path) if u.path else p
        if not path.exists(): errors.append((f,dest,'missing path'))
        elif u.fragment and path.suffix=='.md' and unquote(u.fragment) not in anchors(path): errors.append((f,dest,'unknown anchor'))
        local+=1
print(json.dumps(dict(localLinks=local,historicalCommitLinks=pinned,errors=errors),ensure_ascii=False,indent=2))
raise SystemExit(bool(errors))
