Closes #170

## 变更

```text
rulesets.schema.json
├─ YAML Language Server 补全固定字段和枚举，定位结构错误
└─ sync 先检查 Schema、source 引用、输入选择和产物路径，再访问上游及产物仓库

stable/shared/
├─ domains.json 与 domains.srs
├─ networks.json 与 networks.srs
└─ _delivery/ 按产物登记交付和文件归属
```

共用目录内，各规则集可以独立交付和删除。删除一集后，保留集的 JSON/SRS 字节和当前版本保持有效。正式 16 集配置迁移由 #174 跟踪。

## 验证证据

- VS Code Red Hat YAML 扩展 1.24.0 使用相对 Schema 路径，实测字段及枚举补全、悬停说明和结构诊断。编辑器接受自定义 source 名，引用在 sync 入口核对。
- 20 个配置失败用例核对诊断行列号、字段路径及同步整次退出，覆盖重复键、无效结构、输入选择和最终文件路径冲突。
- 独立目标 `acceptance-issue-170` 使用受控上游、内存 Git 和 sing-box 1.14.4。断言四个稳定入口、单集删除和历史清理结果，并用 GitHub 递归树形状回归以 `activation.json` 命名的目录。GitHub 写入适配器另核对元数据路径和分支约束。
- 本分支已更新到包含 #169 的 `main`（`01cff57`）。在 `265269e` 上通过 54 项定向测试，统一验收入口的 `check-native` 通过 466 项常规检查测试和 335 项原生集成测试，零失败、零跳过。
- PR 常规 CI 与手动 Linux 原生 CI 通过，均覆盖 `265269e`。 [常规 CI](https://github.com/wangyingang/sing-box-config-manager/actions/runs/45159581624) · [Linux 原生 CI](https://github.com/wangyingang/sing-box-config-manager/actions/runs/45159609705)
- 本地双轴审查发现 Git 目录条目的误判、操作契约与实现的差异，以及诊断测试断言过宽，已修复并复验。云端 Codex 审查覆盖 `265269e`，没有 findings 或未解决讨论。 [云端审查](https://github.com/wangyingang/sing-box-config-manager/pull/178#issuecomment-7098549954)

## 合并影响

v4 隔离交付记录按产物保存。父工单 #167 规定 v4 从空状态启用。实际 GitHub 产物发布由后续交付工单跟踪。
