"""Exercise the installed VS Code YAML extension through Language Server Protocol."""
import json
from pathlib import Path
import select
import subprocess
import sys
import time

schema = Path("packages/rule-set-pipeline/config/rulesets.schema.json").resolve()
server = subprocess.Popen(["node", sys.argv[1], "--stdio"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
sequence = 0

def send(message):
    payload = json.dumps({"jsonrpc": "2.0", **message}, ensure_ascii=False).encode()
    server.stdin.write(f"Content-Length: {len(payload)}\r\n\r\n".encode() + payload)
    server.stdin.flush()

def receive():
    if not select.select([server.stdout], [], [], 12)[0]:
        raise TimeoutError("YAML language server did not respond")
    headers = {}
    while (line := server.stdout.readline().strip()):
        key, value = line.decode().split(":", 1)
        headers[key] = value
    body = b""
    length = int(headers["Content-Length"])
    while len(body) < length:
        body += server.stdout.read(length - len(body))
    return json.loads(body)

def request(method, params):
    global sequence
    sequence += 1
    send({"id": sequence, "method": method, "params": params})
    while True:
        response = receive()
        if "method" in response and "id" in response:
            send({"id": response["id"], "result": None})
        elif response.get("id") == sequence:
            assert "error" not in response, response
            return response["result"]

def notify(method, params):
    send({"method": method, "params": params})

def open_yaml(name, content):
    header = "# yaml-language-server: $schema=./rulesets.schema.json\n"
    uri = (schema.parent / (name + ".yml")).as_uri()
    document = {"uri": uri, "languageId": "yaml", "version": 1, "text": header + content}
    notify("textDocument/didOpen", {"textDocument": document})
    return uri

def complete(name, marked, expected, excluded=()):
    line = next(index for index, text in enumerate(marked.splitlines(), 1) if "|" in text)
    character = marked.splitlines()[line - 1].index("|")
    uri = open_yaml(name, marked.replace("|", ""))
    result = request("textDocument/completion", {"textDocument": {"uri": uri}, "position": {"line": line, "character": character}})
    assert result is not None, (name, result)
    labels = {item["label"].strip() for item in result["items"]}
    assert set(expected).issubset(labels) and not set(excluded).intersection(labels), (name, expected, excluded, labels)
    print(f"{name}: {', '.join(sorted(labels))}", flush=True)

def diagnostics(name, content):
    uri = open_yaml(name, content)
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        response = receive()
        if response.get("method") == "textDocument/publishDiagnostics" and response["params"]["uri"] == uri:
            messages = [(item["range"]["start"]["line"] + 1, item["message"]) for item in response["params"]["diagnostics"]]
            print(f"{name}: {messages}", flush=True)
            return messages
    raise TimeoutError(name)

try:
    request("initialize", {"processId": None, "rootUri": schema.parent.as_uri(), "capabilities": {}, "initializationOptions": {"l10nPath": str(Path(sys.argv[1]).parent / "l10n")}})
    notify("initialized", {})
    notify("workspace/didChangeConfiguration", {"settings": {"yaml": {"schemaStore": {"enable": False}, "completion": True, "hover": True, "validate": True}}})
    complete("root-fields", "|\n", ["schemaVersion", "candidateRetentionDays", "sources", "ruleSets", "target"])
    complete("fetch-methods", "sources:\n  custom-name:\n    fetch:\n      method: |\n", ["url", "github-branch"])
    url_formats = ["v2fly-dlc-yaml", "openai-voice-json", "sing-box-source-json"]
    branch_formats = ["clash-rule-list", "cidr-text", "domain-suffix-text"]
    complete("url-input-formats", "sources:\n  custom-name:\n    fetch: {method: url, url: https://rules.example.test/input.json}\n    format: |\n",
             url_formats, branch_formats)
    complete("branch-file-formats", "ruleSets:\n  demo:\n    data:\n      source: custom-name\n      file: rules/example\n      format: |\n",
             branch_formats, url_formats)
    complete("rule-set-fields", "ruleSets:\n  demo:\n    |\n", ["data", "filter", "artifact", "publishPath"])
    uri = open_yaml("description", "ruleSets:\n  demo:\n    publishPath: stable/demo\n")
    result = request("textDocument/hover", {"textDocument": {"uri": uri}, "position": {"line": 3, "character": 8}})
    assert "不同规则集可以共用" in json.dumps(result, ensure_ascii=False), result
    print("publishPath hover:", result["contents"], flush=True)

    target = "schemaVersion: 4\ncandidateRetentionDays: 30\ntarget: {repository: wangyingang/sing-box-rule-artifacts, branch: acceptance-issue-170}\n"
    url = "sources:\n  custom-name:\n    fetch: {method: url, url: https://rules.example.test/example.json}\n    format: sing-box-source-json\n"
    rule = "ruleSets:\n  demo:\n    data: {source: custom-name}\n    publishPath: stable/demo\n    artifact: demo\n"
    assert diagnostics("valid", target + url + rule) == []
    assert diagnostics("freeform-source-reference", target + url + rule.replace("source: custom-name", "source: mistyped")) == []
    invalid = diagnostics("unknown-field-wrong-enum", target + url.replace("sing-box-source-json", "unknown") + rule.replace("artifact", "artifcat"))
    assert any(line == 8 and "unknown" not in msg and "sing-box-source-json" in msg for line, msg in invalid), invalid
    assert any(line == 13 and "artifcat" in msg for line, msg in invalid), invalid
    wrong_fetch = diagnostics("wrong-fields-for-fetch-method", target + url.replace("method: url, url:", "method: github-branch, url:") + rule)
    assert any("repository" in msg for _, msg in wrong_fetch), wrong_fetch
    branch = "sources:\n  custom-name:\n    fetch: {method: github-branch, repository: owner/project, branch: main}\n"
    branch_rule = rule.replace("source: custom-name", "source: custom-name, file: rules/example, format: cidr-text, list: all")
    valid_clash = branch_rule.replace("cidr-text, list: all", "clash-rule-list") + "    filter: {include: {type: {anyOf: [DOMAIN-SUFFIX]}}}\n"
    assert diagnostics("valid-branch-file", target + branch + valid_clash) == []
    dlc = url.replace("sing-box-source-json", "v2fly-dlc-yaml").replace("example.json}", "example.yml, sha256Url: https://rules.example.test/example.yml.sha256}")
    dlc_rule = rule.replace("source: custom-name", "source: custom-name, list: all") + "    filter: {exclude: {tags: {allOf: ['!cn', example]}}}\n"
    assert diagnostics("valid-named-list-and-checksum", target + dlc + dlc_rule) == []
    incompatible = diagnostics("invalid-file-selection-and-filter", target + branch + branch_rule + "    filter: {include: {type: {anyOf: [DOMAIN]}}}\n")
    assert len(incompatible) >= 2, incompatible
    empty = diagnostics("empty-filter", target + branch + branch_rule.replace("cidr-text, list: all", "clash-rule-list") + "    filter: {exclude: {type: {anyOf: []}}}\n")
    assert any("too few items" in msg for _, msg in empty), empty
    print("PASS: schema association, field and enum completion, hover, and structure diagnostics", flush=True)
finally:
    server.terminate()
    server.wait(timeout=5)
