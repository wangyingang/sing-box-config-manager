Closes #173

## 变更

`sing-box-source-json` 读取 Source Format v4，通过现有 `sync` 入口成对交付 JSON 和 SRS。两种格式保留默认规则的字段分组、顶层条目边界，以及嵌套的 `and`、`or` 和 `invert`。多条规则跳过后只剩一条可转换的默认规则时，用逻辑规则包裹，维持它与外层条件原有的匹配关系。

无法保真表达的条目按顶层规则跳过。转换报告记录原始下标、字段或规则类型及失败原因。校验覆盖原生解析器能定位的无效值和 SRS 嵌套深度。所有条目均跳过时保留已有交付，真正的空数组可以交付为空规则集。

## 验证证据

- `6d32ffeefd895d024f470e78309acaf1f4ce52f1` 在干净工作区完成 `check-native`，446 项常规测试和 360 项原生集成测试全部通过，零失败、零跳过。证据在 `.verification/issue-173/6d32ffe/`，完整性报告在 `.verification/issue-173/inspect-6d32ffe/report.json`。
- #173 使用独立目标 `acceptance-issue-173` 和 `stable/issue-173/combined.{json,srs}`。测试通过受控 HTTPS 和内存 Git 验证发布，使用 sing-box 1.14.4 实际编译、加载和匹配。验证域名与 IPv4/IPv6、AND 条件全满足／仅满足一个／全不满足、嵌套逻辑、坏规则跳过、防止匹配范围扩大及候选恢复。
- 已合并包含 #169、#171、#172 的 `main` `9c02d79` 后复验。42 项定向测试覆盖组合规则、固定 URL、GitHub 分支与原生产物验证。[当前提交的常规 CI](https://github.com/wangyingang/sing-box-config-manager/actions/runs/45162226828)
- Linux 原生回归覆盖合入 #171 后的 `0d05abf` 并通过。合入 #172 后的最新提交已通过上述本地全量验证和常规 CI。[Linux 原生回归](https://github.com/wangyingang/sing-box-config-manager/actions/runs/45161098531)

## 审查与合并

本地审查发现的顶层分组、无效子条件隔离、候选恢复报告及 SRS 深度问题已修复并验证。两轮云端 Codex 审查均无 findings 或待处理讨论。第二轮覆盖 `1db7e3a`，后续集成 #171 和 #172 的合并调整尚未经云端审查。[云端复审](https://github.com/wangyingang/sing-box-config-manager/pull/179#issuecomment-7098787736)

旧候选继续按原构建策略复验。正式 16 集配置迁移由 #174 继续跟踪。若其他并行 PR 再先合入，以最新 `main` 复验受影响行为后再合并。
